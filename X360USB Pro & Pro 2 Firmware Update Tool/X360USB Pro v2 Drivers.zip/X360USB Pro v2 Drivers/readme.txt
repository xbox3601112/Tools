If you have any problems installing the X360USB PRO 2 drivers, this is how to fix.

The X360USB PRO 2 has two sets of drivers, one for the CK3i Drive power controller and the other for the X360USB PRO USB Data Controller

Open dm.jpg to see what correctly installed drivers look like in device manager

if you have a problem with one of the drivers (usually a yellow exclamation mark next to the device name) simply right click and uninsstall it then manually delete the files attributed to the device that you uninstalled. These files are shown in ck3i_driver_details.jpg and x360usb_driver_details.jpg

This sometimes happens if you had older versions of CK3 or X360USB previousley installed

For help and support please use the Xecuter support forums www.team-xecuter.com/forums
