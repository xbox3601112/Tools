XECUTER X360USB PRO FIRMWARE v20.1

You must use the X360USB PRO Update Tool Version: 0.12 or later to program this file. Do not use an earlier version.

All X360USB latest downloads can be found at http://forums.360mods.net/downloads.php

Changes:

v20.1
- added DG5S vendor support

v18.1
- Liteon Turbo Mode added. If you thought it was fast before..... 
- Slim Read / Write functions added.
- Optimized all Phat read / write functions
- Improved Hitachi code
- Embedded Phatkey code - much faster Liteon key extraction with Probe 3 / PMT
- Various tweaks and other improvements

v17.1
- Initial Release