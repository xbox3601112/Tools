-----------------------------------------------------------------------------------------------------
Nand&CoolRunner Flasher USB v1.1
-----------------------------------------------------------------------------------------------------

Questa � una versione modificata del firmware per il Nand Flasher USB/SPI che aggiunge la logica
necessaria a programmare una CPLD Xilinx CoolRunner II in modo che sia utilizzabile con RGH. 

Le nuove operazioni sono implementate senza effetti collaterali, il programmatore continuer� a 
funzionare regolarmente anche come USB/SPI.

PIC Compatibili:  PIC18F2455/2550/4455/4550 (bootloader 0x800)

CPLD Compatibili: XC2C64A / XC2C32A (usare xsvf_alt.exe se avete una CPLD differente) 

Richiesti driver libusb versione 1.2.5.0 o successiva.

-----------------------------------------------------------------------------------------------------
Istruzioni
-----------------------------------------------------------------------------------------------------

1) Aggiornamento del firmware PIC (necessario solo la prima volta):

- Attivare il bootloader del PIC (chiudere il jumper).
- Avviare PDFSUSB e scrivere il file "PICFLASH_XSVF.HEX".
- Disattivare il bootloader del PIC (aprire il jumper).

2) Connessione della CPLD:

- Collegare il CoolRunner II al PIC come mostrato in "schematic.jpg".

  schemi alternativi: 	
  	- schematic_reg.jpg utilizza un regolatore da 3.3 V al posto del diodo zener. 
	- schematic_5v.jpg prevede un livello di 5V per le uscite, normalmente funziona, 
	  ma potrebbe provocare danni al CoolRunner II.

3) Programmazione della CPLD:

- Utilizzare il comando

	xsvf.exe <file_name>

  dove <file_name> � il nome del file .xsvf da programmare.

  In caso di problemi nel riconoscimento della CPLD provare ad utilizzare xsvf_alt.exe.

-----------------------------------------------------------------------------------------------------
FILE XSVF
-----------------------------------------------------------------------------------------------------

Sono inclusi file base per l'RGH in formato XSVF:

- jasper.xsvf		Rev. Jasper  /  CPLD XC2C64A
- falcon.xsvf		Rev. Falcon  /  CPLD XC2C64A
- zephyr.xsvf		Rev. Zephyr  /  CPLD XC2C64A
- opus.xsvf		Rev. Opus    /  CPLD XC2C64A
- trinity.xsvf		Rev. Trinity /  CPLD XC2C64A

I file con il suffisso "32" contengono l'implementazione su 32 macrocelle del codice RGH 
(disponibile per le sole revisioni "FAT"):

- jasper32.xsvf		Rev. Jasper  /  CPLD XC2C32A
- falcon32.xsvf		Rev. Falcon  /  CPLD XC2C32A
- zephyr32.xsvf		Rev. Zephyr  /  CPLD XC2C32A

Per creare xsvf compatibili a partire dai file svf � possibile utilizzare il traduttore 
svf2xsvf, incluso nell'omonima cartella. La linea di comando �:

	svf2xsvf.exe -i <file_svf> -o <file_xsvf>

-----------------------------------------------------------------------------------------------------
FILE EXTRA
-----------------------------------------------------------------------------------------------------

- PicXBoot.HEX				Bootloader PIC (0x800)
- PicXBoot_ReadMe.txt			Readme del bootloader
